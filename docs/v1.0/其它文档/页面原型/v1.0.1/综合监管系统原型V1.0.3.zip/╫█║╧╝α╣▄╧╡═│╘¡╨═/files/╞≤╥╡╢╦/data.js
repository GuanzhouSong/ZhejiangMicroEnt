﻿$axure.loadCurrentPage(
(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,c,d,e,f,g,h,g,i,[j],k,_(l,m,n,o,p,q,r,_(),s,_(t,u,v,w,x,_(y,z,A,B),C,null,D,E,F,E,G,H,I,null,J,K,L,M,N,O,P,K),Q,_(),R,_(),S,_(T,[])),U,_(),V,_());}; 
var b="url",c="企业端.html",d="generationDate",e=new Date(1474860758422.24),f="isCanvasEnabled",g=false,h="isAdaptiveEnabled",i="variables",j="OnLoadVariable",k="page",l="packageId",m="e8de7cdbf8f948998b7636bbf0ca2e63",n="type",o="Axure:Page",p="name",q="企业端",r="notes",s="style",t="baseStyle",u="627587b6038d43cca051c114ac41ad32",v="pageAlignment",w="center",x="fill",y="fillType",z="solid",A="color",B=0xFFFFFFFF,C="image",D="imageHorizontalAlignment",E="near",F="imageVerticalAlignment",G="imageRepeat",H="auto",I="favicon",J="sketchFactor",K="0",L="colorStyle",M="appliedColor",N="fontName",O="微软雅黑",P="borderWidth",Q="adaptiveStyles",R="interactionMap",S="diagram",T="objects",U="masters",V="objectPaths";
return _creator();
})());